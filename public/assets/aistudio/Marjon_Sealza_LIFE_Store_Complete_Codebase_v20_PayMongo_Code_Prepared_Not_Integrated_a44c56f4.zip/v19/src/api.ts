import type { OrderLookup, Product } from './types';

const API_BASE = (import.meta.env.VITE_API_BASE_URL || 'https://marjonsealza-paymongo.emeritabuilder.workers.dev').replace(/\/$/, '');

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || 'Request failed. Please try again.');
  return body as T;
}

export const api = {
  products: () => request<{ products: Product[] }>('/api/products'),
  createCheckout: (payload: {
    items: { productId: string; quantity: number }[];
    customer: { name: string; email: string; phone?: string };
  }) => request<{ checkoutUrl: string; referenceNumber: string }>('/api/checkout', {
    method: 'POST', body: JSON.stringify(payload)
  }),
  order: (reference: string) => request<{ order: OrderLookup }>(`/api/orders/${encodeURIComponent(reference)}`)
};
