import { useEffect, useMemo, useState } from 'react';
import { api } from './api';
import type { OrderLookup, Product } from './types';

type Cart = Record<string, number>;
const money = (amount: number) => new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount);

function getQuery(name: string) {
  return new URLSearchParams(window.location.search).get(name);
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<Cart>(() => {
    try {
      const saved = sessionStorage.getItem('ms-life-store-cart');
      return saved ? JSON.parse(saved) as Cart : {};
    } catch { return {}; }
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [customer, setCustomer] = useState({ name: '', email: '', phone: '' });
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState<OrderLookup | null>(null);
  const [orderLoading, setOrderLoading] = useState(false);

  const reference = getQuery('reference');
  const page = getQuery('page');
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/';
  const standaloneStore = pathname === '/store';
  const standaloneCheckout = pathname === '/checkout';

  useEffect(() => {
    try { sessionStorage.setItem('ms-life-store-cart', JSON.stringify(cart)); } catch { /* storage may be disabled */ }
  }, [cart]);

  useEffect(() => {
    api.products()
      .then(data => setProducts(data.products))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!reference || page !== 'success') return;
    setOrderLoading(true);
    api.order(reference).then(data => setOrder(data.order))
      .catch(e => setError(e.message))
      .finally(() => setOrderLoading(false));
  }, [reference, page]);

  const cartItems = useMemo(() => products
    .filter(p => (cart[p.id] || 0) > 0)
    .map(product => ({ product, quantity: cart[product.id] })), [products, cart]);
  const total = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  const add = (id: string) => setCart(prev => ({ ...prev, [id]: Math.min(20, (prev[id] || 0) + 1) }));
  const remove = (id: string) => setCart(prev => {
    const next = { ...prev };
    if ((next[id] || 0) <= 1) delete next[id]; else next[id] -= 1;
    return next;
  });

  async function checkout(event: React.FormEvent) {
    event.preventDefault();
    setError(''); setNotice('');
    if (!cartItems.length) { setError('Add at least one item to your cart.'); return; }
    if (!customer.name.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
      setError('Enter your name and a valid email address.'); return;
    }
    setBusy(true);
    try {
      const result = await api.createCheckout({
        items: cartItems.map(({ product, quantity }) => ({ productId: product.id, quantity })),
        customer
      });
      window.location.assign(result.checkoutUrl);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not start checkout.');
      setBusy(false);
    }
  }

  return <div className="site-shell">
    <header className="topbar">
      <a className="brand" href="/" aria-label="Marjon Sealza home"><span className="brand-mark">MS</span><span>MARJON SEALZA<small>LIFE & STORE</small></span></a>
      <nav aria-label="Main navigation"><a href="/#about">About</a><a href="/#services">Services</a><a href="/store">Store</a><a href="/checkout">Checkout</a><a href="/#contact">Contact</a></nav>
    </header>

    <main>
      {page === 'cancel' && <section className="notice-panel"><h2>Checkout cancelled</h2><p>Your order has not been marked as paid. You can return to the store and try again.</p><a className="button" href="/#store">Return to store</a></section>}
      {page === 'success' ? <section className="notice-panel"><h2>Payment status</h2>
        {orderLoading ? <p>Checking the latest order status…</p> : order ? <>
          <p>Reference: <strong>{order.referenceNumber}</strong></p>
          <p>Total: <strong>{money(order.totalAmount)}</strong></p>
          <p>Status: <span className={`status status-${order.status}`}>{order.status}</span></p>
          {order.status === 'paid' ? <p>Payment is confirmed. Thank you for your order.</p> : <p>Payment is not yet confirmed. This page does not confirm payment by itself; status updates when the verified PayMongo webhook is received.</p>}
        </> : <p>Payment confirmation is being checked. If it remains pending, contact support with your order reference.</p>}
        <a className="button" href="/#store">Continue browsing</a>
      </section> : null}

      {!standaloneStore && !standaloneCheckout && <>
      <section className="hero">
        <div className="hero-copy"><p className="eyebrow">PERSONAL PORTFOLIO · DIGITAL STORE</p><h1>Ideas made useful.<br/><span>Built with purpose.</span></h1>
          <p>Explore my work, services, and LIFE & STORE collection in one place.</p><div className="hero-actions"><a className="button" href="#store">Explore the store</a><a className="button button-ghost" href="#services">View services</a></div>
        </div>
        <div className="hero-card"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="hero-monogram">MS</div><p>DESIGN · SOFTWARE · DIGITAL</p></div>
      </section>

      <section id="about" className="content-section about-grid"><div><p className="eyebrow">ABOUT</p><h2>Curiosity into practical solutions.</h2></div><p className="muted">This space brings together my portfolio, services, and online store. Replace this introductory copy with your approved biography and project details before launch.</p></section>

      <section id="services" className="content-section"><p className="eyebrow">WHAT I DO</p><h2>Services</h2><div className="three-cards">
        <article className="info-card"><span className="card-number">01</span><h3>Software & Web</h3><p>Websites, software concepts, workflow tools, and practical digital experiences.</p></article>
        <article className="info-card"><span className="card-number">02</span><h3>Digital Projects</h3><p>Project planning, interface improvements, and implementation support.</p></article>
        <article className="info-card"><span className="card-number">03</span><h3>Consultation</h3><p>Discuss your goals, requirements, and the right next step for your project.</p></article>
      </div></section>

      </>}

      {!standaloneCheckout && <section id="store" className="content-section store-section"><div className="section-heading"><div><p className="eyebrow">LIFE & STORE</p><h2>Explore the collection</h2><p className="muted">Prices are displayed in Philippine pesos. Checkout totals are recalculated on the server.</p></div><div className="cart-badge">Cart · {cartItems.reduce((n, i) => n + i.quantity, 0)} items</div></div>
        {loading ? <p>Loading products…</p> : error && !products.length ? <p className="error">{error}</p> : products.length === 0 ? <p className="muted">No products are published yet. Add products to the server-side catalog to display them here.</p> :
          <div className="product-grid">{products.map(product => <article className="product-card" key={product.id}>
            <div className="product-art"><span>{product.category.toUpperCase()}</span><div>{product.name.slice(0, 1)}</div></div>
            <div className="product-details"><h3>{product.name}</h3><p>{product.description}</p><div className="product-bottom"><strong>{money(product.price)}</strong><button className="button button-small" onClick={() => add(product.id)} disabled={!product.available}>{product.available ? 'Add to cart' : 'Unavailable'}</button></div></div>
          </article>)}</div>}
      </section>

      }

      {!standaloneStore && <section className="content-section checkout-section"><div><p className="eyebrow">SECURE CHECKOUT</p><h2>Your order</h2><p className="muted">You will be redirected to PayMongo Hosted Checkout. Payment is confirmed by the server through a verified webhook.</p>
        <div className="cart-lines">{cartItems.length ? cartItems.map(({ product, quantity }) => <div className="cart-line" key={product.id}><div><strong>{product.name}</strong><small>{money(product.price)} each</small></div><div className="quantity"><button aria-label={`Remove one ${product.name}`} onClick={() => remove(product.id)}>−</button><span>{quantity}</span><button aria-label={`Add one ${product.name}`} onClick={() => add(product.id)}>+</button></div><strong>{money(product.price * quantity)}</strong></div>) : <p className="muted">Your cart is empty.</p>}</div>
        <div className="total-line"><span>Estimated total</span><strong>{money(total)}</strong></div>
      </div>
      <form className="checkout-form" onSubmit={checkout}><h3>Customer details</h3><label>Full name<input required maxLength={100} autoComplete="name" value={customer.name} onChange={e => setCustomer({ ...customer, name: e.target.value })}/></label><label>Email address<input required type="email" maxLength={254} autoComplete="email" value={customer.email} onChange={e => setCustomer({ ...customer, email: e.target.value })}/></label><label>Phone (optional)<input type="tel" maxLength={30} autoComplete="tel" value={customer.phone} onChange={e => setCustomer({ ...customer, phone: e.target.value })}/></label>
        {error && <p className="error" role="alert">{error}</p>}{notice && <p role="status">{notice}</p>}
        <button className="button button-wide" type="submit" disabled={busy || !cartItems.length}>{busy ? 'Preparing secure checkout…' : 'Continue to PayMongo'}</button><p className="fine-print">By continuing, you agree to the store’s applicable terms, privacy, and refund policies. Add approved policy links before production launch.</p>
      </form></section>

      }

      {!standaloneStore && !standaloneCheckout && <section id="contact" className="contact-band"><div><p className="eyebrow">LET'S CONNECT</p><h2>Have a project in mind?</h2><p>Reach out to discuss a collaboration, service, or store question.</p></div><a className="button button-ghost" href="mailto:hello@marjonsealza.life">Contact by email</a></section>}
    </main>
    <footer className="footer"><span>© {new Date().getFullYear()} Marjon Sealza</span><div><a href="#about">About</a><a href="#contact">Support</a><a href="/privacy.html">Privacy</a><a href="/terms.html">Terms</a><a href="/refunds.html">Refunds</a></div></footer>
  </div>;
}
